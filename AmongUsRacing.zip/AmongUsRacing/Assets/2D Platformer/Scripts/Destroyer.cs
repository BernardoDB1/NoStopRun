using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyer : MonoBehaviour
{
    public Canvas GameOver;

    // Start is called before the first frame update
    private void Start()
    {
        GameOver.gameObject.SetActive(false);
    }

    void OnTriggerEnter2D(Collider2D outro) {
        if (outro.gameObject.tag == "Player")
        {
            Time.timeScale = 0;
            GameOver.gameObject.SetActive(true);
            return;
        }
        else
        {
            if (outro.gameObject.transform.parent)
                Destroy
                    (outro.gameObject.tramsform.parent.gameObject);
            else
                Destroy(outro.gameObject);
        }
    }
}

